from django_celery_beat.models import CrontabSchedule, cronexp

from rest_framework import serializers
from dvadmin.utils.serializers import CustomModelSerializer
from dvadmin.utils.viewset import CustomModelViewSet

CrontabSchedule.__str__ = lambda self : '{0} {1} {2} {3} {4} {5}'.format(
            cronexp(self.minute), cronexp(self.hour),
            cronexp(self.day_of_month), cronexp(self.month_of_year),
            cronexp(self.day_of_week), str(self.timezone)
        )

class CrontabScheduleSerializer(CustomModelSerializer):


    crontab_str = serializers.SerializerMethodField()

    class Meta:
        model = CrontabSchedule
        exclude = ('timezone',)
    
    def get_crontab_str(self, instance):
        return instance.__str__()


class CrontabScheduleModelViewSet(CustomModelViewSet):
    """
    CrontabSchedule crontab调度模型
    minute 分钟
    hour 小时
    day_of_week 每周的周几
    day_of_month 每月的某一天
    month_of_year 每年的某一个月

    """
    queryset = CrontabSchedule.objects.all()
    serializer_class = CrontabScheduleSerializer
    ordering = 'minute'  # 默认排序
